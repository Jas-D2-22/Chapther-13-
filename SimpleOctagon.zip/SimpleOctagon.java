public class SimpleOctagon {

    // GeometricObject class as an inner abstract class
    public abstract static class GeometricObject {
        public abstract double getArea();
        public abstract double getPerimeter();
    }

    // Octagon class that extends GeometricObject and implements Comparable and Cloneable
    public static class Octagon extends GeometricObject implements Comparable<Octagon>, Cloneable {
        private double side;

        public Octagon(double side) {
            this.side = side;
        }

        public double getSide() {
            return side;
        }

        public void setSide(double side) {
            this.side = side;
        }

        @Override
        public double getArea() {
            return (2 + 4 / Math.sqrt(2)) * side * side;
        }

        @Override
        public double getPerimeter() {
            return 8 * side;
        }

        @Override
        public int compareTo(Octagon o) {
            return Double.compare(getArea(), o.getArea());
        }

        @Override
        public Octagon clone() throws CloneNotSupportedException {
            return (Octagon) super.clone();
        }
    }

    public static void main(String[] args) {
        // Create an Octagon object
        Octagon octagon1 = new Octagon(5);

        // Clone the Octagon object
        Octagon octagon2 = null;
        try {
            octagon2 = octagon1.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        // Compare the two objects
        int comparisonResult = octagon1.compareTo(octagon2);

        // Print results
        System.out.println("Octagon 1 Area: " + octagon1.getArea());
        System.out.println("Octagon 2 Area: " + octagon2.getArea());
        System.out.println("Comparison Result: " + comparisonResult);
    }
}
